export const MONGO_URL ="mongodb+srv://amit:12345@inncluster0.jfz8ykl.mongodb.net/myFirstDb?authSource=admin&replicaSet=atlas-nuokn5-shard-0&w=majority&readPreference=primary&appname=mongodb-vscode%200.6.10&retryWrites=true&w=true"
export const MONGODBLOCAL_URL ="http://localhost:4000/"
export const JWT_SECRET = "sdasfsdfgdfhsdsadsads"
export const PORT = 4000
